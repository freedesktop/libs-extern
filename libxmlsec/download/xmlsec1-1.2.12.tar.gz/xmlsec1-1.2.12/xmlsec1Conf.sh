#
# Configuration file for using the XML library in GNOME applications
#
prefix="/usr"
exec_prefix="${prefix}"
libdir="${exec_prefix}/lib"
includedir="${prefix}/include"

XMLSEC_LIBDIR="${exec_prefix}/lib"
XMLSEC_INCLUDEDIR=" -D__XMLSEC_FUNCTION__=__FUNCTION__ -DXMLSEC_NO_GOST=1 -DXMLSEC_NO_XKMS=1 -I${prefix}/include/xmlsec1   -I/usr/include/libxml2   -I/usr/include/libxml2   -I/usr/kerberos/include   -DXMLSEC_OPENSSL_097=1 -DXMLSEC_CRYPTO_OPENSSL=1 -DXMLSEC_CRYPTO=\\\"openssl\\\""
XMLSEC_LIBS="-L${exec_prefix}/lib -lxmlsec1-openssl -lxmlsec1  -ldl  -lxml2 -lpthread -lz -lm   -lxslt -lxml2 -lpthread -lz -lm   -L/usr/kerberos/lib -lssl -lcrypto -lgssapi_krb5 -lkrb5 -lcom_err -lk5crypto -lresolv -ldl -lz  "
MODULE_VERSION="xmlsec-1.2.12-openssl"

